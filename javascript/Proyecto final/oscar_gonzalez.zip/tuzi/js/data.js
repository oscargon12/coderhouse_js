// Defino las opciones de ingredientes para cada categoría con arrays
let ingredientes_1 = ['-', 'Avena', 'Crema de leche', 'Kumis', 'Leche', 'Leche condensada', 'Arequipe', 'Yogurt', 'Queso']
let ingredientes_2 = ['-', 'Carne de res', 'Pollo', 'Carne de cerdo', 'Pescado', 'Pescado robalo']
let ingredientes_3 = ['-', 'Arroz', 'Lentejas', 'Fríjoles', 'Alverja seca', 'Garbanzos', 'Caraotas']
let ingredientes_4 = ['-', 'Jamón', 'Jamón de pavo', 'Jamón de cerdo', 'Salchichas', 'Salchichón']
let ingredientes_5 = ['-', 'Atún', 'Salchcichas', 'Fríjoles enlatados', 'Maíz', 'Duraznos', 'Liches', 'Piña']
let ingredientes_6 = ['-', 'Manzanas', 'Uvas', 'Peras', 'Naranjas', 'Sandía', 'Duraznos', 'Plátanos', 'Papaya']
let ingredientes_7 = ['-', 'Alverja', 'Zanahoria', 'Tomate', 'Cebolla larga', 'Cebolla cabezona', 'Pimentón', 'Brocoli']
let ingredientes_8 = ['-', 'Azucar', 'Sal', 'Salsa de tomate', 'Mayonesa', 'Mostaza', 'Vinagreta']
